class HighCard extends Combo {
  static isAvailable(cards) {
    return true
  }
}