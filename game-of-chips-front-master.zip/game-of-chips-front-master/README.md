# Game Of Chips

:warning: Ceci n'est pas du poker

Attention, la procédure de lancement est particulièrement complexe :

- double-cliquer sur le fichier `index.html`