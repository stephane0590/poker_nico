let data = {
  "combos": 
    {
      "HighCard": "Hauteur",
      "Pair": "Paire",
      "TwoPairs": "Deux paires",
      "ThreeOfAKind": "Brelan",
      "Straight": "Suite",
      "Flush": "Flush",
      "FullHouse": "Full",
      "FourOfAKind": "Carré",
      "StraightFlush": "Quinte Flush",
      "RoyalFlush": "Quinte Flush Royale"
    }
}